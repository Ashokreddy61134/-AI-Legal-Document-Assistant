from src.text_splitter import split_documents

def test_splitter():
    chunks = split_documents([{"text":"hello "*300, "source":"x.txt", "page":None}])
    assert len(chunks) > 1
