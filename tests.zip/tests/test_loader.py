from src.document_loader import load_document

def test_loader_import():
    assert callable(load_document)
