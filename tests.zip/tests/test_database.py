import tempfile

def test_database_module_import():
    from src import database
    assert callable(database.init_db)
