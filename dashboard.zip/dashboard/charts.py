import plotly.express as px
from pathlib import Path
from collections import Counter
from .analytics import get_metrics


def show_dashboard(st):
    m = get_metrics()
    a,b,c,d = st.columns(4)
    a.metric("Documents", m["documents"]); b.metric("Questions", m["questions"]); c.metric("Avg Retrieval Score", f"{m['avg_score']:.3f}"); d.metric("RAG Index", "Ready" if m["index"] else "Not built")
    types = Counter(p.suffix.lower().replace(".", "").upper() for p in Path("data/documents").glob("*"))
    if types: st.plotly_chart(px.bar(x=list(types.keys()), y=list(types.values()), labels={"x":"Type","y":"Files"}), use_container_width=True)
