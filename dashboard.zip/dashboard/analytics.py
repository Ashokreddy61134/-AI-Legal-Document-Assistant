from pathlib import Path
from src.database import stats


def get_metrics():
    docs = len([p for p in Path("data/documents").glob("*") if p.suffix.lower() in {".pdf", ".docx", ".txt"}])
    questions, avg_score = stats()
    return {"documents": docs, "questions": questions, "avg_score": avg_score, "index": Path("vectorstore/index/index.faiss").exists()}
