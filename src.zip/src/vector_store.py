from pathlib import Path
from langchain_community.vectorstores import FAISS
from langchain_core.documents import Document
from .embeddings import get_embeddings
from config import VECTOR_DIR


def build_index(chunks):
    docs = [Document(page_content=c["text"], metadata={"source": c["source"], "page": c.get("page")}) for c in chunks]
    db = FAISS.from_documents(docs, get_embeddings())
    Path(VECTOR_DIR).mkdir(parents=True, exist_ok=True)
    db.save_local(VECTOR_DIR)
    return db


def load_index():
    path = Path(VECTOR_DIR) / "index.faiss"
    if not path.exists(): return None
    return FAISS.load_local(VECTOR_DIR, get_embeddings(), allow_dangerous_deserialization=True)
