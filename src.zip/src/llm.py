from langchain_groq import ChatGroq
from config import GROQ_API_KEY, LLM_MODEL


def get_llm():
    if not GROQ_API_KEY:
        raise RuntimeError("GROQ_API_KEY is missing. Add it to .env")
    return ChatGroq(model=LLM_MODEL, groq_api_key=GROQ_API_KEY, temperature=0)
