from langchain_text_splitters import RecursiveCharacterTextSplitter
from config import CHUNK_SIZE, CHUNK_OVERLAP


def split_documents(records):
    splitter = RecursiveCharacterTextSplitter(chunk_size=CHUNK_SIZE, chunk_overlap=CHUNK_OVERLAP)
    chunks = []
    for r in records:
        for text in splitter.split_text(r["text"]):
            chunks.append({"text": text, "source": r["source"], "page": r.get("page")})
    return chunks
