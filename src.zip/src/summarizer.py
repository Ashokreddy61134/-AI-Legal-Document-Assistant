from .document_loader import load_document
from .llm import get_llm


def summarize_file(path):
    records = load_document(path)
    text = "\n\n".join(r["text"] for r in records)
    text = text[:30000]
    prompt = f"""Summarize this legal document for a non-lawyer. Cover purpose, parties, obligations, dates, payment, termination, liability, confidentiality, dispute resolution, and important review points. Do not invent facts.\n\nDOCUMENT:\n{text}"""
    return get_llm().invoke(prompt).content
