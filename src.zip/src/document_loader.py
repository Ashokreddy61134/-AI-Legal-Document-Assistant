from pathlib import Path
from pypdf import PdfReader
from docx import Document as DocxDocument


def load_document(file_path: str):
    path = Path(file_path)
    suffix = path.suffix.lower()
    documents = []
    if suffix == ".pdf":
        reader = PdfReader(str(path))
        for i, page in enumerate(reader.pages, 1):
            text = page.extract_text() or ""
            if text.strip():
                documents.append({"text": text, "source": path.name, "page": i})
    elif suffix == ".docx":
        doc = DocxDocument(str(path))
        text = "\n".join(p.text for p in doc.paragraphs if p.text.strip())
        if text.strip(): documents.append({"text": text, "source": path.name, "page": None})
    elif suffix == ".txt":
        text = path.read_text(encoding="utf-8", errors="ignore")
        if text.strip(): documents.append({"text": text, "source": path.name, "page": None})
    else:
        raise ValueError("Supported formats: PDF, DOCX, TXT")
    if not documents: raise ValueError("No readable text found in the document.")
    return documents
