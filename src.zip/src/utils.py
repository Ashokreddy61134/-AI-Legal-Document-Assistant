from pathlib import Path


def save_uploaded_file(uploaded_file, directory="data/documents"):
    Path(directory).mkdir(parents=True, exist_ok=True)
    path = Path(directory) / uploaded_file.name
    path.write_bytes(uploaded_file.getbuffer())
    return str(path)
