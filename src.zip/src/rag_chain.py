from pathlib import Path
from langchain_core.prompts import ChatPromptTemplate
from .document_loader import load_document
from .text_splitter import split_documents
from .vector_store import build_index, load_index
from .llm import get_llm
from config import DATA_DIR


def build_rag():
    chunks = []
    for p in Path(DATA_DIR).glob("*"):
        if p.suffix.lower() in {".pdf", ".docx", ".txt"}:
            chunks.extend(split_documents(load_document(str(p))))
    if not chunks: return None
    return build_index(chunks)


def ask_rag(question, k=4):
    db = load_index() or build_rag()
    if db is None: raise RuntimeError("Upload at least one legal document first.")
    docs_scores = db.similarity_search_with_score(question, k=k)
    context = "\n\n".join(d.page_content for d, _ in docs_scores)
    prompt = ChatPromptTemplate.from_template("""You are an AI legal document assistant. Answer only from the provided document context. Do not invent clauses, laws, facts, or legal advice. If the answer is not in the context, say that it is not found in the uploaded documents.\n\nContext:\n{context}\n\nQuestion: {question}\n\nGive a concise answer and mention relevant source documents/pages.""")
    response = get_llm().invoke(prompt.format_messages(context=context, question=question))
    sources = [{"source": d.metadata.get("source"), "page": d.metadata.get("page"), "score": float(s)} for d, s in docs_scores]
    return response.content, sources
