import sqlite3
from datetime import datetime
from config import DB_PATH


def init_db():
    with sqlite3.connect(DB_PATH) as con:
        con.execute("CREATE TABLE IF NOT EXISTS questions (id INTEGER PRIMARY KEY AUTOINCREMENT, question TEXT, score REAL, created_at TEXT)")


def log_question(question, score=None):
    with sqlite3.connect(DB_PATH) as con:
        con.execute("INSERT INTO questions(question, score, created_at) VALUES (?, ?, ?)", (question, score, datetime.now().isoformat(timespec="seconds")))


def stats():
    with sqlite3.connect(DB_PATH) as con:
        count = con.execute("SELECT COUNT(*) FROM questions").fetchone()[0]
        avg = con.execute("SELECT AVG(score) FROM questions WHERE score IS NOT NULL").fetchone()[0]
    return count, avg or 0
