from .document_loader import load_document
from .llm import get_llm


def analyze_risk(path):
    records = load_document(path)
    text = "\n\n".join(r["text"] for r in records)[:30000]
    prompt = f"""Review this legal document for areas that deserve human/legal review. Organize findings under termination, payment, liability, confidentiality, penalties, renewal, dispute resolution, unusual obligations, and other notable clauses. Use LOW/MEDIUM/HIGH only as descriptive review flags, explain the clause, and quote no more than short snippets. Do not claim this is legal advice.\n\nDOCUMENT:\n{text}"""
    return get_llm().invoke(prompt).content
